# Dashboard de Renta Variable

Dashboard estático para GitHub Pages.

## Archivos
- `index.html`: aplicación completa.
- `README.md`: instrucciones.

## Publicar en GitHub Pages
1. Crea un repositorio nuevo.
2. Sube `index.html` y `README.md` a la raíz.
3. Ve a Settings → Pages.
4. Source: Deploy from branch.
5. Branch: main / root.
6. Guarda y abre la URL que genera GitHub.

## Datos
Los datos se guardan en el navegador con localStorage. Usa la pestaña **Backup seguro** para exportar/importar un JSON.
