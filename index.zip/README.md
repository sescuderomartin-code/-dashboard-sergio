# Dashboard Renta Variable

Archivo principal: `index.html`.

Para GitHub Pages:
1. Sube `index.html` a un repositorio.
2. Activa Settings > Pages > Deploy from branch.
3. Selecciona main / root.
