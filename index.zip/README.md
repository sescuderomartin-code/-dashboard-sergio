# Dashboard Renta Variable

Archivo preparado para GitHub Pages.

## Uso
1. Descomprime el ZIP.
2. Sube `index.html` a la raíz del repositorio, no el ZIP.
3. En GitHub: Settings → Pages → Deploy from branch → main → /root.
4. Espera 1-3 minutos y recarga la URL.
