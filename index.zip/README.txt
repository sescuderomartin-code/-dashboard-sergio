Dashboard Renta Variable

Para Cloudflare Pages:
1. Sube este ZIP directamente.
2. Comprueba que index.html, styles.css y app.js quedan en la raíz del despliegue.
3. El ZIP guarda la app. El backup JSON guarda tus datos.

Para GitHub Pages:
1. Descomprime el ZIP.
2. Sube index.html, styles.css y app.js a la raíz del repositorio.
3. No los metas dentro de una carpeta si vas a publicar la raíz.
